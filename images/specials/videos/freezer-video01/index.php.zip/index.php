<?php ini_set("include_path", ".:../:./i:../i:../../i:../../../i"); ?>


<!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>rokma • portfolio • photography</title>
<meta name="description" content="Hello, this is rokma! ">
<meta name="author" content="rokma" />
<meta name="page-topic" content="art,photography,contemporary,communication,creativity,art direction," />
<meta name="rating" content="All" />
<meta name="audience" content="General" />
<meta name="copyright" content="rokma" />
<meta name="robots" content="all" />
<meta name="distribution" content="global" />
<meta name="content-language" content="en" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" href="/css/normalize.css">
<link rel="stylesheet" href="/css/flexslider.css">
<link rel="stylesheet" href="/css/rok.css">

<link rel="stylesheet" href="style-adjust.css">

<script src="/js/libs/modernizr-2.6.1.min.js"></script>
</head>

<body>
  <!--[if lt IE 7]><p class=chromeframe>Your browser is <em>ancient!</em> <a href="http://browsehappy.com/">Upgrade to a different browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to experience this site. ;D</p><![endif]-->
  
<div id="left" role="main">  
<div class="ta"><div class="taro"><div class="tace">
<div class="inside clearfix">  
<div id="fixed_toggle">
<?php include 'header.php'; ?> 
</div><!--/fixed_toggle-->

<?php include 'p.php'; ?>
</div>
</div></div></div>
</div><!--/left-->


<div id="right">
 <div class="ta"><div class="taro"><div class="tace">
  <div class="inside clearfix">  

   
   <nav>
   <?php  include 'one_menu.php'; ?>
   </nav>
   
   <?php include 'i.htm'; ?>

  </div>
 </div></div></div>
</div><!--/right-->



  <!-- Grab Google CDN's jQuery, with a protocol relative URL; fall back to local if offline -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="/js/libs/jquery-1.8.0.min.js"><\/script>')</script>
  
  <script src="/js/libs/jquery.flexslider-min.js"></script>
  <script src="/js/plugins.js"></script>
  <script src="/js/script.js"></script>
  <!--/scripts -->

  <!-- Asynchronous Google Analytics -->
  <script>
    var _gaq=[['_setAccount','UA-1305149-1'],['_trackPageview']];
    (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
    g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g,s)}(document,'script'));
  </script>
</body>
</html>

