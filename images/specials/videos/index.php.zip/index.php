<?php ini_set("include_path", ".:../:./i:../i:../../i:../../../i"); ?>
<?php include 'page.php'; ?> 
